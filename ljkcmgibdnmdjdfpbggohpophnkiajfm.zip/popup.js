function findX(percent) {
	for (let i = 0; i < 200; i++) {
		console.log(Math.floor((i-8)/165*100));
		if (Math.floor((i-8)/165*100) == percent) {
			console.log('***********');
			return i;
		}
	}
}
window.onload = () => {
	chrome.storage.sync.get(['roll','cheat','percent'], function(result) {
		if (typeof result.roll === 'undefined' || typeof result.cheat === 'undefined' || typeof result.percent === 'undefined') {
			chrome.storage.sync.set({roll: 'off'}, function() {
				chrome.storage.sync.set({cheat: 'off'}, function() {
					chrome.storage.sync.set({percent: '50'}, function() {
						let rb = 128 - (Math.abs(Math.floor((findX(50) * 0.766)))-6);
						$('#tri').css('left',findX(50) + 'px');
						$('#percentageSlider').css('backgroundColor','rgb('+rb+',128,'+rb+')');
						$('#statusPercent').html('Rickroll Frequency: '+50+'%')
					});
				});
			});
		}
		else {
			if (result.roll == "on") {
				$('#extensionToggle .slider-bt').removeClass('toLeft');
				$('#extensionToggle .slider-bt').addClass('toRight');
				$('#extensionToggle').css('backgroundColor','green');
			}
			if (result.cheat == "on") {
				$('#cheatToggle .slider-bt').removeClass('toLeft');
				$('#cheatToggle .slider-bt').addClass('toRight');
				$('#cheatToggle').css('backgroundColor','green');
			}
			console.log('ok');
			console.log(result.percent);
			console.log(findX(result.percent));
			let rb = 128 - (Math.abs(Math.floor((findX(result.percent) * 0.766)))-6);
			$('#tri').css('left',findX(result.percent) + 'px');
			$('#percentageSlider').css('backgroundColor','rgb('+rb+',128,'+rb+')');
			$('#statusPercent').html('Rickroll Frequency: '+result.percent+'%')
		}
	});
}
$(".slider-bg").click(function (e) {
	$(this).children('.slider-bt').toggleClass('toLeft');
	$(this).children('.slider-bt').toggleClass('toRight');
	if ($(this).attr('id') == "extensionToggle") {
		chrome.storage.sync.get(['roll'], function(result) {
			let toSet = (result.roll == 'on') ? 'off' : 'on';
			chrome.storage.sync.set({roll: toSet}, function() {
				chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
					chrome.tabs.sendMessage(tabs[0].id, {greeting: "reload"});
				});
			});
		});
	}
	else {
		chrome.storage.sync.get(['cheat'], function(result) {
			let toSet = (result.cheat == 'on') ? 'off' : 'on';
			chrome.storage.sync.set({cheat: toSet}, function() {
				chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
					  chrome.tabs.sendMessage(tabs[0].id, {greeting: "reload"});
				});
			});
		});
	}
	$(this).css('backgroundColor') == 'rgb(0, 128, 0)' ? $(this).css('backgroundColor','gray') : $(this).css('backgroundColor','green');
});
var percent;
var x = 0;
var moveSlider = false;
document.addEventListener("mouseup", () => {
	if (moveSlider == true) {
		chrome.storage.sync.get(['percent'], function(result) {
			chrome.storage.sync.set({percent: percent}, function() {
				chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
					  chrome.tabs.sendMessage(tabs[0].id, {greeting: "reload"});
				});
			});
		});
	}
	moveSlider = false;
})
$('#tri').on('mousedown', () => {
	moveSlider = true;
})
$('#percentageSlider').on('click', () => {
	console.log('click');
	let rb = 128 - (Math.abs(Math.floor((x * 0.766)))-6);
	percent = Math.floor((x-8)/165*100);
	if (x > 8 && x < 175) {
		$('#tri').css('left',x + 'px');
		$('#percentageSlider').css('backgroundColor','rgb('+rb+',128,'+rb+')');
		$('#statusPercent').html('Rickroll Frequency: '+percent+'%')
	}
	chrome.storage.sync.get(['percent'], function(result) {
		chrome.storage.sync.set({percent: percent}, function() {
			chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
				  chrome.tabs.sendMessage(tabs[0].id, {greeting: "reload"});
			});
		});
	});
})
document.addEventListener("mousemove", e => {
	x = e.pageX;
})
var i = 0;
window.setInterval(() => {
	let rb = 128 - (Math.abs(Math.floor((x * 0.766)))-6);
	percent = Math.floor((x-8)/165*100);
	if (moveSlider && x > 8 && x < 175) {
		$('#tri').css('left',x + 'px');
		$('#percentageSlider').css('backgroundColor','rgb('+rb+',128,'+rb+')');
		$('#statusPercent').html('Rickroll Frequency: '+percent+'%')
	}
},50);