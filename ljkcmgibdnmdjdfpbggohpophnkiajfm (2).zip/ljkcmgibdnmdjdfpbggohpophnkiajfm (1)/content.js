chrome.storage.sync.get(['roll','cheat','percent'], function(result) {
  if (result.roll == "on") {
    var a = document.getElementsByTagName("a");
    for (var i = 0; i < a.length; i++) {
      var random = Math.random() * 100;
      if (random <= parseInt(result.percent)) {
        a[i].href = "http://bit.ly/30QqsQ2";
        if (result.cheat == "on") {
        	a[i].innerHTML = "[R]" + a[i].innerHTML;
        }
      }
    }
  }
});
chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    if (request.greeting === "reload") window.location.reload();
  }
);
